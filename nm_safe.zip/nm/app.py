import streamlit as st
import requests

from utils.document_formatter import (
    format_docx,
    format_pdf,
    format_txt
)


st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide"
)


st.title("⚖️ LegalEase")
st.subheader("AI-Powered Legal Document Generator")

st.write(
    "Create professional legal document drafts using Generative AI."
)


# -----------------------------
# USER INPUT
# -----------------------------

document_type = st.text_input(
    "Document Type",
    placeholder="Example: Employment Contract"
)


parties = st.text_area(
    "Parties Involved",
    placeholder="Example: John Doe (Employee), ABC Corp (Employer)"
)


terms = st.text_area(
    "Terms & Conditions",
    placeholder=(
        "Example: Salary ₹25,000 per month; "
        "30 days notice period; "
        "Confidentiality must be maintained"
    )
)


dates = st.text_input(
    "Effective Date",
    placeholder="Example: 07/10/2026"
)


# -----------------------------
# GENERATE DOCUMENT
# -----------------------------

if st.button("🚀 Generate Document"):

    if not document_type or not parties or not terms or not dates:

        st.warning("Please fill all the fields.")

    else:

        request_data = {
            "document_type": document_type,
            "parties": parties,
            "terms": terms,
            "dates": dates
        }

        try:

            response = requests.post(
                "http://127.0.0.1:8000/generate",
                json=request_data
            )

            if response.status_code == 200:

                result = response.json()

                st.session_state["document"] = result["document"]

                st.success("Document generated successfully!")

            else:

                st.error("Failed to generate document.")

        except Exception as e:

            st.error(
                "Backend server is not running. "
                "Please start FastAPI first."
            )


# -----------------------------
# DISPLAY DOCUMENT
# -----------------------------

if "document" in st.session_state:

    st.divider()

    st.subheader("📄 Generated Document")

    edited_document = st.text_area(
        "Edit your document",
        value=st.session_state["document"],
        height=500
    )

    st.session_state["document"] = edited_document

    st.divider()

    st.subheader("Download Document")

    # TXT
    txt_file = format_txt(edited_document)

    st.download_button(
        label="📄 Download TXT",
        data=txt_file,
        file_name="LegalEase_Document.txt",
        mime="text/plain"
    )

    # DOCX
    docx_file = format_docx(
        edited_document,
        document_type
    )

    st.download_button(
        label="📝 Download DOCX",
        data=docx_file,
        file_name="LegalEase_Document.docx",
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )

    # PDF
    pdf_file = format_pdf(
        edited_document,
        document_type
    )

    st.download_button(
        label="📕 Download PDF",
        data=pdf_file,
        file_name="LegalEase_Document.pdf",
        mime="application/pdf"
    )