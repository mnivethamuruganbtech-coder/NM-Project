from docx import Document
from docx.shared import Pt
from fpdf import FPDF
import io


def format_txt(text):
    return text


def format_docx(text, doc_type):

    document = Document()

    # Title
    title = document.add_heading(doc_type, level=0)
    title.alignment = 1

    # Body
    paragraphs = text.split("\n")

    for paragraph in paragraphs:
        if paragraph.strip():
            p = document.add_paragraph(paragraph)

            for run in p.runs:
                run.font.name = "Times New Roman"
                run.font.size = Pt(12)

    # Save into memory
    file_stream = io.BytesIO()
    document.save(file_stream)
    file_stream.seek(0)

    return file_stream


def format_pdf(text, doc_type):

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Title
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, doc_type, ln=True, align="C")

    pdf.ln(10)

    # Body
    pdf.set_font("Arial", size=11)

    for paragraph in text.split("\n"):
        if paragraph.strip():
            pdf.multi_cell(0, 7, paragraph)
            pdf.ln(2)

    pdf_bytes = pdf.output(dest="S").encode("latin-1")

    return pdf_bytes