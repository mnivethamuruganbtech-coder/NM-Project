import os
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file")

genai.configure(api_key=API_KEY)


class GeminiDocumentGenerator:

    def __init__(self):
        self.model = genai.GenerativeModel("gemini-1.5-pro")

    def generate_document(
        self,
        document_type,
        parties,
        terms,
        dates
    ):
        prompt = f"""
You are a professional legal document drafting assistant.

Create a structured and professional legal document.

Document Type:
{document_type}

Parties Involved:
{parties}

Terms and Conditions:
{terms}

Effective Date:
{dates}

Requirements:
1. Give the document a clear title.
2. Include the parties involved.
3. Include the effective date.
4. Organize the agreement into proper sections.
5. Include the given terms and conditions.
6. Use professional and formal language.
7. Do not invent important personal information.
8. Make the document easy to read.
9. Add a final signature section.

Important:
This is an AI-generated draft and should be reviewed by a qualified legal professional.
"""

        response = self.model.generate_content(prompt)

        return response.text